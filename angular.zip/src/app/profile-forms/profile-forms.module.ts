import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileFormsRoutingModule } from './profile-forms-routing.module';
import { httpInterceptorProviders } from '../core/interceptors';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProfileFormsRoutingModule
  ],
  providers:[httpInterceptorProviders]
})
export class ProfileFormsModule { }
