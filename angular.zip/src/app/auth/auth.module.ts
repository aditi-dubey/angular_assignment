import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import {FormsModule} from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { httpInterceptorProviders } from '../core/interceptors';
import { AuthService } from './services/auth.service';


@NgModule({
  declarations: [RegisterComponent, LoginComponent],
  imports: [CommonModule,FormsModule,HttpClientModule,AuthRoutingModule],
  providers:[AuthService,httpInterceptorProviders]
})
export class AuthModule { }
