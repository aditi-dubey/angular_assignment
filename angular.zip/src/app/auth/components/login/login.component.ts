import { Component, OnInit } from '@angular/core';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   login :Login=new Login();
   constructor(private authService:AuthService,private router:Router) { }
  
   loginSubmit(){
      const newUser:any={
        email:this.login.email,
        password:this.login.password
      }
      this.authService.loginUser(newUser).subscribe(
        (res)=>{
          console.log('User Logged in')
          this.router.navigate(['/dashboard'])
          localStorage.setItem('token',res.token)
        }
      )
   }
  ngOnInit(): void {
  }


}
