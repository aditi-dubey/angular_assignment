// These interceptors we need along all the modules
// suppose we have 5 interceptors, then wherever we have to use interceptors there you need to provide all 5 interceptors name

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HeaderInterceptor } from './header.interceptor';

// Here we are using a single interceptor
export const httpInterceptorProviders = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HeaderInterceptor,
    multi: true,
  },
];
