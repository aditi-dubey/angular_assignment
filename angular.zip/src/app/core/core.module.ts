import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { FooterComponent } from './components/layout/footer/footer.component';
import { LandingComponent } from './components/layout/landing/landing.component';
import { NavbarComponent } from './components/layout/navbar/navbar.component';
import { httpInterceptorProviders } from './interceptors';


@NgModule({
  declarations: [FooterComponent, LandingComponent, NavbarComponent],
  imports: [CommonModule,CoreRoutingModule],
  providers:[httpInterceptorProviders],
  exports:[FooterComponent,LandingComponent,NavbarComponent]
})
export class CoreModule { }
